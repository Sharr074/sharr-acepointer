<?php
/**
 * Copyright (c) 2022. PublishPress, All rights reserved.
 */

namespace PublishPress\Future\Framework;

use Exception;

defined('ABSPATH') or die('Direct access not allowed.');

class BaseException extends Exception
{

}
